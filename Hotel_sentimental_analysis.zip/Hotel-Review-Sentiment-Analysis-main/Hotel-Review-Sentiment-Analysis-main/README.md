# Hotel-Review-Sentiment-Analysis
#### This application assists in understanding the customers’ requirements and preferences that will potentially be used to drive improvement.

## Preview of the App
![image](https://user-images.githubusercontent.com/81804267/143064262-6bd767df-7ab6-45bc-bec3-84be9a003e22.png)
